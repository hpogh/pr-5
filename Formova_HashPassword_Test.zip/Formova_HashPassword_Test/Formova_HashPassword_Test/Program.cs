﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HashPasswords;
using Formova_HashPassword_Test.Model;

namespace Formova_HashPassword_Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Регистрация нового пользователя ===\n");

            try
            {
                Helper helper = new Helper();

                Console.Write("Введите имя: ");
                string firstName = Console.ReadLine();

                Console.Write("Введите фамилию: ");
                string lastName = Console.ReadLine();

                string login;
                do
                {
                    Console.Write("Введите логин: ");
                    login = Console.ReadLine();

                    if (helper.LoginExists(login))
                    {
                        Console.WriteLine("Логин занят!");
                    }
                } while (helper.LoginExists(login));

                Console.Write("Введите пароль: ");
                string password = Console.ReadLine();

                // Хеширование пароля
                string hash = HashHelper.GetHash(password);
                Console.WriteLine($"\nХеш пароля: {hash}");

                // Создание пользователя
                Users newUser = new Users
                {
                    first_name = firstName,
                    last_name = lastName,
                    login = login,
                    password_hash = hash,
                    role = "user",
                    created_date = DateTime.Now,
                    is_active = true
                };

                helper.CreateUser(newUser);
                Console.WriteLine("Пользователь добавлен!");

                // Показываем всех пользователей
                Console.WriteLine("\n=== Список пользователей ===");
                foreach (var user in helper.GetUsers())
                {
                    Console.WriteLine($"{user.id}: {user.last_name} {user.first_name} - {user.login}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }

            Console.WriteLine("\nНажмите любую клавишу...");
            Console.ReadKey();
        }
    }
}