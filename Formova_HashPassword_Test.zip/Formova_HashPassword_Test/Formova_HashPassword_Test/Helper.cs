﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Formova_HashPassword_Test.Model;

namespace Formova_HashPassword_Test
{
    internal class Helper
    {
        private static ProviderDBEntities1 _context; 
        public static ProviderDBEntities1 GetContext() 
        {
            if (_context == null)
            {
                _context = new ProviderDBEntities1(); 
            }
            return _context;
        }

        public void CreateUser(Users user)
        {
            GetContext().Users.Add(user);
            GetContext().SaveChanges();
        }

        public bool LoginExists(string login)
        {
            return GetContext().Users.Any(u => u.login == login);
        }

        public List<Users> GetUsers()
        {
            return GetContext().Users.ToList();
        }

        public List<clients> GetClients()
        {
            return GetContext().clients.ToList();
        }

        public List<employees> GetEmployees()
        {
            return GetContext().employees.ToList();
        }

        public List<tariff_plans> GetTariffs()
        {
            return GetContext().tariff_plans.ToList();
        }

        public List<contracts> GetContracts()
        {
            return GetContext().contracts.ToList();
        }
    }
}