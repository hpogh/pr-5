﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace HashPasswords
{
    /// <summary>
    /// Класс для хеширования паролей
    /// </summary>
    public class HashHelper
    {
        /// <summary>
        /// Получить хеш пароля методом SHA256
        /// </summary>
        /// <param name="password">Исходный пароль</param>
        /// <returns>Хеш в верхнем регистре</returns>
        public static string GetHash(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(password);
                byte[] hash = sha256.ComputeHash(bytes);

                StringBuilder result = new StringBuilder();
                for (int i = 0; i < hash.Length; i++)
                {
                    result.Append(hash[i].ToString("X2"));
                }
                return result.ToString();
            }
        }
    }
}